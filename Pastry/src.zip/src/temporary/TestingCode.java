package temporary;

import java.util.logging.Logger;

//import o
public class TestingCode {
	// Logger logger =

	public static void main(String[] args) {

		// logger.info("Logging For Testing Code");
		// logger.info("Logging For Testing Code");

		// logger.log(Level.WARNING, "Warning");
		// // logger.log(Level.FINE, "Fine");
		// logger.log(Level.INFO, "Info");
		// logger.log(Level.OFF, "Off");
		// // logger.log(Level.CONFIG, "Config");
		// // logger.log(Level.FINER, "Finer");
		// // logger.log(Level.FINER, "Finer");
		// // logger.log(Level.FINEST, "Finest");
		// logger.log(Level.SEVERE, "Severe");
		//
		// // logger.log(Level.ALL, "All");
		//
		//
		// System.out.println(new Random().nextInt(2));
		String one = "1298";
		// // // String two = new StringBuilder("FFF5").reverse().toString();
		String two = "9F15";
		if ((Integer.parseInt(two, 16) - Integer.parseInt(one, 16)) >= (65536 / 2)) {
			System.out.println("Left");
			System.out.println((Integer.parseInt(two, 16) - Integer.parseInt(
					one, 16)) - 65536);
		} else {
			System.out.println("Right");
			System.out.println((Integer.parseInt(two, 16) - Integer.parseInt(
					one, 16)));
		}
		// String one ="1236";
		// String two = "1234";
		//
		// System.out.println(one.compareTo(two));

		// }
		//
		// System.out.println('v' == 'v');
		//
		// LinkedHashMap<Integer, Integer> o = new LinkedHashMap<Integer,
		// Integer>();
		// o.put(1, 1);
		// o.put(1, 2);
		// System.out.println(o);
		//
		// System.out.println(Integer.toHexString(11));
		// Set<String> s = new HashSet
		// ArrayList<Integer> x = new ArrayList<Integer>();
		// x.add(1);
		// x.add(2);
		// x.add(3);
		//
		// x.add(4);
		// x.add(5);
		//
		// x.add(36);
		//
		// x.add(7);
		// x.add(8);
		// x.add(4, 6);
		// x.add(0, 1);
		// // x.clear();
		// ArrayList<Integer> y = new ArrayList<Integer>();
		// y.add(1);
		// y.add(2);
		// y.add(3);
		// x.addAll(y);
		//
		// System.out.println(x);
		// String[] e = "fef.fw".split("\\.");
		// System.out.println(e[0]);

	}
}
