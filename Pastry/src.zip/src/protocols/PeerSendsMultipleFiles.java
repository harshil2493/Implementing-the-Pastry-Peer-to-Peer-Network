package protocols;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.util.ArrayList;

public class PeerSendsMultipleFiles {
	ArrayList<PeerSendsDataToPeer> objects;

	public PeerSendsMultipleFiles(
			ArrayList<PeerSendsDataToPeer> dataToSendObject) {
		// TODO Auto-generated constructor stub

		this.objects = dataToSendObject;
	}

	public byte[] getByte() throws Exception {
		// TODO Auto-generated method stub

		byte[] marshalledBytes = null;
		ByteArrayOutputStream baOutputStream = new ByteArrayOutputStream();
		DataOutputStream dout = new DataOutputStream(new BufferedOutputStream(
				baOutputStream));
		dout.writeInt(objects.size());
		for (PeerSendsDataToPeer possibleObjects : objects) {
			dout.writeInt(possibleObjects.fileName.getBytes().length);
			dout.write(possibleObjects.fileName.getBytes());

			dout.writeInt(possibleObjects.metaData.getBytes().length);
			dout.write(possibleObjects.metaData.getBytes());

			dout.writeInt(possibleObjects.fileData.length);
			dout.write(possibleObjects.fileData);
			dout.writeInt(possibleObjects.ID.getBytes().length);
			dout.write(possibleObjects.ID.getBytes());
		}
		dout.flush();

		marshalledBytes = baOutputStream.toByteArray();
		baOutputStream.close();
		dout.close();

		return marshalledBytes;

	}

}
